const express = require("express");
const app = express();
const bodyParser = require("body-parser");
const mongoose = require("mongoose");
const multer = require("multer");
const path = require("path");

const authRoute = require("./routes/auth")
const authUser = require("./routes/user")
const authPost = require("./routes/posts")
const authCat = require("./routes/categories")



app.use(express.json());
app.use("/images", express.static(path.join(__dirname, "images")));
const port = 3001;
const url =
  "mongodb+srv://mellinn:BD66FzK3752O6wQW@myblog.xtbbebq.mongodb.net/blogdb?retryWrites=true&w=majority";

const connectionParams = {};

mongoose
  .connect(url, connectionParams)
  .then(() => {
    console.log("Connected to MongoDB");
  })
  .catch((err) => {
    console.error(`Error connecting to the database. ${err}`);
});


const storage = multer.diskStorage({
  destination: (req, file, callb) => {
    callb(null, "images/");
  },
  
  filename: (req, file, callb) => {
    callb(null, file.fieldname + '-' + Date.now() + path.extname(file.originalname));
  },
  
})

const upload = multer({ storage: storage })
app.post("/upload", upload.single("file"), (req, res) => {
  res.status(200).json("File has been uploaded")
})


app.use("/auth", authRoute)
app.use("/users", authUser)
app.use("/posts", authPost)
app.use("/category", authCat)

app.listen(port, () => {
  console.log(`App is listening at http://localhost:${port}`);
});
